# HT-WPS BREAKER

[ Languages: [English](README.md) ]

High Touch WPS Breaker [HT-WB] is a small tool based on the bash script language, it can help you to extract the wps pin of many vulnerable
routers and get the password, in the last i want to notice that HT-WPS Breaker in its process is using these tools :

* "Piexiewps"
* "Reaver"
* "Bully"
* "Aircrack Suite"
* "Wash"

and some commands in automatic way to do its job i hope you like my tool.

## Preview

![1](http://i.imgur.com/S2Phf7R.jpg)

![2](http://i.imgur.com/fQ2LXBm.jpg)

![3](http://i.imgur.com/MOrVEgg.jpg)

![4](http://i.imgur.com/BrU8UN2.jpg)

![5](http://i.imgur.com/glQ9Qo9.jpg)


## Video

* [New Video](https://www.youtube.com/watch?v=VUiitRwgCtw)
* [Old Video Tutorial](https://www.youtube.com/watch?v=GZX-cDD7gN8)
* [Crack Any Hidden wireless network](https://www.youtube.com/watch?v=jpGIFdM_7zY)

## Here is how to make the script works

* Copy HT-WPS-Breaker.zip to Desktop .
* Open The Terminal .
* Type the following commands :

    - [X] cd Desktop
    - [X] unzip HT-WPS-Breaker.zip
    - [X] cd HT-WPS-Breaker
    - [X] chmod +x HT-WB.sh
    - [X] ./HT-WB.sh  or  bash HT-WB.sh